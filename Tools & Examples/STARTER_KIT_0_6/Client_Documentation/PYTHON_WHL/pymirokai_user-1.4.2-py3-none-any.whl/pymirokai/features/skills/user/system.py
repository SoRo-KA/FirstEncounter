"""This module contains system-related features of the robot."""

from pymirokai.mission import Mission


class SystemUser:
    """Class to handle system-related features of the robot."""

    def enable_motor_functions(self) -> Mission:
        """Calibrate and enable motor functions of the robot.

        Returns:
            Mission: The mission representing the task.
        """
        return Mission(self, "enable_motor_functions")

    def get_battery_level(self) -> Mission:
        """Get current battery level.

        Returns:
            Mission: The mission representing the task.
        """
        return Mission(self, "get_battery_level")
