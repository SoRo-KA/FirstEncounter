#!/usr/bin/env python3
"""This module contains the freeze-related features of the robot."""
from pymirokai.mission import Mission


class FreezeUser:
    """Class to handle freeze-related features of the robot."""

    def freeze(self) -> Mission:
        """Freeze all of the robot's movement.

        Returns:
            Mission: The mission representing the task.
        """
        return Mission(self, "freeze")
