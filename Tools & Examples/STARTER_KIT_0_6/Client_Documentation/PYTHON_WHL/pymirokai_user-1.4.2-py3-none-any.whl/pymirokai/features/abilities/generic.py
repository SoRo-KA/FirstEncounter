#!/usr/bin/env python3
"""This module contains the generic features of the robot."""

from typing import Dict, Any
from pymirokai.utils.async_wrapper import make_async


class Generic:
    """Class to handle generic features of the robot."""

    @make_async
    def get_character_name(self) -> Dict[str, Any]:
        """Get the current character name.

        Returns:
            Dict[str, Any]: The response from the REST API.
        """
        return self.send_command("get_character_name")

    @make_async
    def get_language(self) -> Dict[str, Any]:
        """Get the current language setting.

        Returns:
            Dict[str, Any]: The response from the REST API.
        """
        return self.send_command("get_language")

    @make_async
    def get_publishers(self) -> Dict[str, Any]:
        """Get the list of available publishers.

        Returns:
            Dict[str, Any]: The list of available publishers.
        """
        return self.send_command("get_publishers")
