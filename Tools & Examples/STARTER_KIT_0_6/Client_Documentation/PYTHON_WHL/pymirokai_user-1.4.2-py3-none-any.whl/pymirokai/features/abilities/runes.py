#!/usr/bin/env python3
"""This module contains the runes features of the robot."""

from typing import Dict, Any
from pymirokai.utils.async_wrapper import make_async


class Runes:
    """Class to handle generic features of the robot."""

    @make_async
    def is_seeing(self, rune_id: str) -> Dict[str, Any]:
        """Check if the robot is seeing a specific rune.

        Args:
            rune_id (str): The ID of the rune to check.

        Returns:
            Dict[str, Any]: The response from the REST API.
        """
        return self.send_string("is_seeing", rune_id)

    @make_async
    def get_all_runes_details(self) -> Dict[str, Any]:
        """Get details on all detected runes: ID, RSSI, Angles (horizontal and vertical).

        Returns:
            Dict[str, Any]: The response from the REST API.
        """
        return self.send_command("get_all_runes_details")

    @make_async
    def is_clicked(self, rune_id: str) -> Dict[str, Any]:
        """Check if a rune has been clicked.

        Args:
            rune_id (str): The ID of the rune to check.

        Returns:
            Dict[str, Any]: The response from the REST API.
        """
        return self.send_string("is_clicked", rune_id)

    @make_async
    def is_double_clicked(self, rune_id: str) -> Dict[str, Any]:
        """Check if a rune has been double-clicked.

        Args:
            rune_id (str): The ID of the rune to check.

        Returns:
            Dict[str, Any]: The response from the REST API.
        """
        return self.send_string("is_double_clicked", rune_id)

    @make_async
    def is_long_pressed(self, rune_id: str) -> Dict[str, Any]:
        """Check if a rune has been long-pressed.

        Args:
            rune_id (str): The ID of the rune to check.

        Returns:
            Dict[str, Any]: The response from the REST API.
        """
        return self.send_string("is_long_pressed", rune_id)

    @make_async
    def is_detected(self, rune_id: str) -> Dict[str, Any]:
        """Check if a rune has been detected.

        Args:
            rune_id (str): The ID of the rune to check.

        Returns:
            Dict[str, Any]: The response from the REST API.
        """
        return self.send_string("is_detected", rune_id)

    @make_async
    def get_rune_rssi(self, rune_id: str) -> Dict[str, Any]:
        """Get the RSSI of a rune.

        Args:
            rune_id (str): The ID of the rune to check.

        Returns:
            Dict[str, Any]: The response from the REST API.
        """
        return self.send_string("get_rune_rssi", rune_id)

    @make_async
    def get_rune_angle_of_arrival(self, rune_id: str) -> Dict[str, Any]:
        """Get the angle of arrival of a rune.

        Args:
            rune_id (str): The ID of the rune to check.

        Returns:
            Dict[str, Any]: The response from the REST API.
        """
        return self.send_string("get_rune_angle_of_arrival", rune_id)

    @make_async
    def get_clicked_runes(self) -> Dict[str, Any]:
        """Get a list of all clicked runes.

        Returns:
            Dict[str, Any]: The response from the REST API.
        """
        return self.send_command("get_clicked_runes")

    @make_async
    def get_double_clicked_runes(self) -> Dict[str, Any]:
        """Get a list of all double-clicked runes.

        Returns:
            Dict[str, Any]: The response from the REST API.
        """
        return self.send_command("get_double_clicked_runes")

    @make_async
    def get_long_pressed_runes(self) -> Dict[str, Any]:
        """Get a list of all long-pressed runes.

        Returns:
            Dict[str, Any]: The response from the REST API.
        """
        return self.send_command("get_long_pressed_runes")

    @make_async
    def get_detected_runes(self) -> Dict[str, Any]:
        """Get a list of all detected runes.

        Returns:
            Dict[str, Any]: The response from the REST API.
        """
        return self.send_command("get_detected_runes")

    @make_async
    def rune_association(
        self,
        rune_id: str,
        virtual_id: str = "",
        label: str = "",
        description: str = "",
        rune_class: str = "",
    ) -> Dict[str, str]:
        """Assign a properties to a rune based on its ID.

        Args:
            rune_id (str): The ID of the rune to update.
            virtual_id (str): the virtual_id to associate with the rune.
            label (str): the label to associate with the rune.
            description (str): the description to associate with the rune.
            class (str): the class to associate with the rune.

        Returns:
            Dict[str, str]: The response from the REST API.
        """
        return self.send_dict(
            "rune_association",
            {
                "rune_id": rune_id,
                "virtual_id": virtual_id,
                "label": label,
                "description": description,
                "class": rune_class,
            },
        )
