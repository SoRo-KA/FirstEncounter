import threading
import typing as tp
import logging

OPENCV_INSTALLED = True
try:
    import cv2
except ModuleNotFoundError:
    OPENCV_INSTALLED = False

logger = logging.getLogger("pymirokai")


class VideoAPI:
    def __init__(self, display=False, timeout=5000):
        """
        Initialize the OpenCVStreamClient class.

        Args:
            display (bool): Whether to display the stream in an OpenCV window.
            timeout (int): Timeout in milliseconds for opening the video stream.
        """
        self.stream_url = None
        self.display = display
        self.capture = None
        self.current_frame = None
        self.running = False
        self.lock = threading.Lock()
        self.is_connected = False
        self.timeout = timeout
        self.thread = None

    def connect(self, stream_url: str):
        """
        Connect to the video stream using OpenCV.

        Args:
            stream_url (str): The RTSP stream URL.
        """
        self.stream_url = stream_url
        try:
            self.capture = cv2.VideoCapture(self.stream_url)
            if hasattr(cv2, "CAP_PROP_OPEN_TIMEOUT_MSEC"):
                self.capture.set(cv2.CAP_PROP_OPEN_TIMEOUT_MSEC, self.timeout)

            if not self.capture.isOpened():
                raise Exception(f"Failed to open video stream at {self.stream_url} within {self.timeout}ms")

            logger.info(f"Connected to video stream at {self.stream_url}")
            self.is_connected = True
        except Exception as e:
            logger.error(f"Error connecting to stream {stream_url}: {e}")
            self.is_connected = False
            raise

    def capture_stream(self):
        self.running = True
        while self.running:
            ret, frame = self.capture.read()
            if not ret:
                logger.warning(f"Failed to capture frame from stream {self.stream_url}")
                break

            with self.lock:
                self.current_frame = frame
                logger.debug(f"Captured frame from {self.stream_url}")

    def get_current_frame(self):
        """
        Expose the current frame for external access.

        Returns:
            The most recent video frame.
        """
        with self.lock:
            return self.current_frame

    def toggle_display(self):
        """
        Toggle the display on or off during the video stream.
        """
        with self.lock:
            self.display = not self.display
            if not self.display:
                cv2.destroyAllWindows()
            logger.debug(f"Display {'ON' if self.display else 'OFF'}")

    def set_display(self, value: bool):
        """
        Set the display status.

        Args:
            value (bool): Whether to display the stream.
        """
        with self.lock:
            self.display = value
            if not self.display:
                cv2.destroyAllWindows()
            logger.debug(f"Display {'ON' if self.display else 'OFF'}")

    def close(self):
        """
        Close the OpenCV video stream and clean up.
        """
        self.running = False
        if self.thread and self.thread.is_alive():
            self.thread.join()
        if self.capture:
            self.capture.release()
        cv2.destroyAllWindows()
        self.is_connected = False
        logger.info("Closed video stream")

    def start(self, stream_url: str):
        """
        Start the video stream in a separate thread.

        Args:
            stream_url (str): The RTSP stream URL.
        """
        self.connect(stream_url=stream_url)
        self.thread = threading.Thread(target=self.capture_stream, daemon=True)
        self.thread.start()


class VideoStreamManager:
    def __init__(self, stream_base_url: tp.Optional[str] = None):
        """
        Initialize the VideoStreamManager to manage multiple video streams.
        """
        self.streams = {}
        self.lock = threading.Lock()
        self.stream_base_url = stream_base_url
        self.display_thread = None
        self.display_running = False

    def add_stream(self, stream_name: str, stream_url: str):
        """
        Add a new video stream to the manager.

        Args:
            stream_name (str): A unique name for the stream.
            stream_url (str): The RTSP stream URL.
        """
        if not OPENCV_INSTALLED:
            logger.warning("opencv-python is not installed, video streaming is disabled.")
            return
        if not self.stream_base_url:
            raise ValueError('Please set stream_base_url before adding a stream. ("http://<ip>:8554")')
        if stream_name in self.streams:
            raise ValueError(f"Stream with name {stream_name} already exists.")

        video_api = VideoAPI()
        with self.lock:
            self.streams[stream_name] = video_api
        video_api.start(stream_url=f"{self.stream_base_url}/{stream_url}")
        logger.info(f"Added stream {stream_name} with URL {stream_url}")

    def set_display(self, stream_name: str, value: bool):
        """Set the display status of input stream name.

        Args:
            stream_name (str): Name of the stream to set display status.
            value (bool): Whether to display the stream.
        """
        if stream_name not in self.streams:
            logger.error(f"Unknown stream {stream_name}")
            return

        with self.lock:
            self.streams[stream_name].set_display(value)

        if value:
            # Ensure the display thread is running
            if not self.display_running:
                self.start_display_thread()

    def start_display_thread(self):
        """Start a single thread to handle frame display."""
        if self.display_thread and self.display_thread.is_alive():
            return  # Thread already running

        self.display_running = True
        self.display_thread = threading.Thread(target=self.display_frames, daemon=True)
        self.display_thread.start()

    def display_frames(self):
        logger.info("Starting display thread...")
        while self.display_running:
            with self.lock:
                for stream_name, stream in self.streams.items():
                    if stream.display:
                        frame = stream.get_current_frame()
                        if frame is not None:
                            logger.debug(f"Displaying frame for stream {stream_name}")
                            cv2.imshow(f"Stream: {stream_name}", frame)
                        else:
                            logger.debug(f"No frame available for stream {stream_name}")
            if cv2.waitKey(1) & 0xFF == ord("q"):
                logger.info("Stopping display on user request.")
                self.display_running = False
                break
        cv2.destroyAllWindows()

    def remove_stream(self, stream_name: str):
        """
        Remove a video stream from the manager.

        Args:
            stream_name (str): The name of the stream to remove.
        """
        with self.lock:
            if stream_name in self.streams:
                self.streams[stream_name].close()
                del self.streams[stream_name]
                logger.info(f"Removed stream {stream_name}")

    def close_all_streams(self):
        """
        Close all streams managed by the VideoStreamManager.
        """
        with self.lock:
            for stream_name, video_api in self.streams.items():
                video_api.close()
            self.streams.clear()
        self.display_running = False
        if self.display_thread:
            self.display_thread.join()
        logger.info("Closed all streams")
