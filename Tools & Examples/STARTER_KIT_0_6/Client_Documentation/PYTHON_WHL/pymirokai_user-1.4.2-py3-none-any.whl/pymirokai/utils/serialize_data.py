import json

from typing import Any, Iterable


def serialize_data(data: Any) -> Any:
    """Serialize data to a JSON string.

    Args:
        data (Any): The data to serialize.

    Returns:
        Any: The serialized data.
    """
    if isinstance(data, tuple):
        return tuple(serialize_data(item) for item in data)
    elif isinstance(data, dict):
        return {key: serialize_data(value) for key, value in data.items()}
    elif isinstance(data, Iterable) and not isinstance(data, (str, bytes)):
        return [serialize_data(item) for item in data]
    elif isinstance(data, (str, bool, int, float)):
        return data
    else:
        try:
            return json.dumps(data)
        except TypeError:
            return str(data)
