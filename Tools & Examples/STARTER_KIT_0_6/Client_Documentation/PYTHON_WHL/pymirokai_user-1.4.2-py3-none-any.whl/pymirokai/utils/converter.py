from typing import Optional
from pymirokai.enums import Arm, Hand, Ear


def arm_to_arm_entity_identifier(arm: Arm) -> str:
    """Convert an Arm enum to its corresponding entity identifier string.

    Args:
        arm (Arm): The Arm enum value.

    Returns:
        str: The corresponding entity identifier string.
    """
    match arm:
        case Hand.LEFT:
            return "left_arm"
        case Hand.RIGHT:
            return "right_arm"


def hand_to_hand_entity_identifier(hand: Hand) -> str:
    """Convert a Hand enum to its corresponding entity identifier string.

    Args:
        hand (Hand): The Hand enum value.

    Returns:
        str: The corresponding entity identifier string.
    """
    match hand:
        case Hand.LEFT:
            return "left_hand"
        case Hand.RIGHT:
            return "right_hand"


def ear_to_ear_entity_identifier(ear: Ear) -> Optional[str]:
    """Convert an Ear enum to its corresponding entity identifier string.

    Args:
        ear (Ear): The Ear enum value.

    Returns:
        Optional[str]: The corresponding entity identifier string, or None if not recognized.
    """
    match ear:
        case Ear.LEFT:
            return "left_ear"
        case Ear.RIGHT:
            return "right_ear"
    return None
