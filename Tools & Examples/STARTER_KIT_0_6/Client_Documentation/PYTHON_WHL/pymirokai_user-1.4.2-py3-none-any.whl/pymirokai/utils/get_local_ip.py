"""Get the local IP address of the machine."""

import logging
import socket


def get_local_ip() -> str:
    """
    Get the local IPv4 address of the current machine using a dummy UDP connection.

    Returns:
        Local IP as a string, or '127.0.0.1' if retrieval fails.
    """
    socket_obj = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        socket_obj.connect(("10.255.255.255", 1))
        ip = socket_obj.getsockname()[0]
    except Exception as e:
        logging.warning(f"Could not determine local IP, defaulting to 127.0.0.1: {e}")
        ip = "127.0.0.1"
    finally:
        socket_obj.close()
    return ip
