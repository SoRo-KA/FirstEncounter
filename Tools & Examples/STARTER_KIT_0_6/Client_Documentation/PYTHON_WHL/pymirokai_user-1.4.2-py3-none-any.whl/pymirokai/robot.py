#!/usr/bin/env python3
"""This module contains the Robot class which integrates all features and handles operations."""

import asyncio
import logging
import os
import threading
from typing import Callable, Optional, Any, Dict

import coloredlogs

from pymirokai.api_version import API_VERSION
from pymirokai.core.rest_api import RestAPI
from pymirokai.core.video_api import VideoStreamManager
from pymirokai.core.websocket_api import WebSocketAPI
from pymirokai.utils.async_wrapper import make_async
from pymirokai.utils.get_local_ip import get_local_ip
from pymirokai.features.abilities import Interaction, Navigation, Behavior, Generic, Runes
from pymirokai.features.skills import (
    Animate,
    Freeze,
    Interact,
    Manipulate,
    Navigate,
    Planning,
    ShowOff,
    System,
    Transport,
)
from pymirokai.models.data_models import (
    StrCommand,
    IntCommand,
    FloatCommand,
    BoolCommand,
    ListCommand,
    DictCommand,
    NoArgCommand,
)

logger = logging.getLogger("pymirokai")


def initialize_coloredlogs(loglevel: Optional[int] = None) -> None:
    """Initialize logging with colored logs.

    This function sets up the logging configuration using the coloredlogs library,
    which provides colored output for log messages.

    Args:
        loglevel (int): The logging level to use (e.g., 'DEBUG' (10), 'INFO' (20), 'WARNING' (30)).
    """
    loglevel = int(os.getenv("PYLOG_LEVEL", 20)) if loglevel is None else loglevel
    coloredlogs.install(
        logger=logger,
        level=loglevel,
        fmt="[%(asctime)s] [%(levelname)s] (%(threadName)s) %(message)s",
        datefmt="%H:%M:%S",
    )
    logger.setLevel(loglevel)
    logger.propagate = False


class BaseRobot:
    """Base class for the robot, handling the integration of various features and API interactions.

    This class manages the connection to both REST and WebSocket APIs, allowing for the execution of skills
    and management of robot features.

    Attributes:
        retry_interval (int): Interval between connection retry attempts.
        rest_api (RestAPI): Instance for REST API communication.
        websocket_api (WebSocketAPI): Instance for WebSocket API communication.
        running (asyncio.Event): Event to control the running state of the robot.
        loop (Optional[asyncio.AbstractEventLoop]): Event loop for asynchronous operations.
        thread (Optional[threading.Thread]): Thread for running asynchronous tasks.
        connection (Optional[BaseRobot.Connection]): Manages the connection state and operations.
    """

    def __init__(
        self,
        retry_interval: int = 5,
        api_version: str = API_VERSION,
        loglevel: str = None,
    ) -> None:
        """Initialize the BaseRobot with REST and WebSocket API configurations.

        Args:
            retry_interval (int): Time interval between retry attempts for API connections.
            api_version (str): API version to use for communication.
            loglevel (str): The level of logging detail.
        """
        initialize_coloredlogs(loglevel)
        self.retry_interval = retry_interval
        self.rest_api = RestAPI(api_version, retry_interval)
        self.websocket_api = WebSocketAPI(retry_interval)
        self.video_stream_manager = VideoStreamManager(None)
        self.running = asyncio.Event()
        self.loop: Optional[asyncio.AbstractEventLoop] = None
        self.thread: Optional[threading.Thread] = None
        self.running.set()
        self.connection: Optional[BaseRobot.Connection] = None

    class Connection:
        """Handles the robot's connection to the REST and WebSocket APIs.

        Manages the start, stop, and monitoring of connections to the robot's APIs.

        Attributes:
            robot (BaseRobot): The parent robot instance.
            rest_api_url (str): URL for the REST API.
            websocket_api_url (str): URL for the WebSocket API.
            rest_api (Optional[asyncio.Task]): Task for managing REST API connection.
            websocket_api (Optional[asyncio.Task]): Task for managing WebSocket API connection.
            finished (asyncio.Future): Future indicating the completion of connection tasks.
        """

        def __init__(
            self,
            robot: "BaseRobot",
            rest_api_url: str,
            websocket_api_url: str,
            video_server_url: str,
            api_key: str,
            use_uds: bool = False,
        ) -> None:
            """Initialize the Connection with API URLs and the parent robot instance.

            Args:
                robot (BaseRobot): The parent robot instance.
                rest_api_url (str): URL for the REST API.
                websocket_api_url (str): URL for the WebSocket API.
                api_key (str): API key to use.
                use_uds (bool): Whether to use Unix Domain Socket (UDS).
            """
            self.robot = robot
            self.websocket_api_url = websocket_api_url
            self.api_key = api_key
            self.video_server_url = video_server_url

            self.use_uds = use_uds
            self.rest_api_url = rest_api_url

            self.rest_api: Optional[asyncio.Task] = None
            self.websocket_api: Optional[asyncio.Task] = None
            self._jwt_token = None
            self.video_stream_manager: Optional[asyncio.Task] = None
            self.finished = asyncio.Future()

        async def __aenter__(self) -> "BaseRobot":
            await self.connected()
            return self.robot

        async def __aexit__(
            self, exc_type: Optional[type], exc_value: Optional[BaseException], traceback: Optional[Any]
        ) -> None:
            await self.cancel_and_complete()
            logger.info("Robot disconnected")

        async def run_without_cancelled_error(self) -> None:
            """Run the connection tasks, handling cancellation errors gracefully."""
            try:
                await self.run()
            except asyncio.CancelledError:
                pass

        def set_jwt_token(self, token: str):
            """Update the shared JWT token."""
            self._jwt_token = token

        def get_jwt_token(self) -> str:
            """Retrieve the latest JWT token."""
            return self._jwt_token

        async def run(self) -> None:
            """Start monitoring and managing data fetching from the APIs."""
            self.robot.video_stream_manager.stream_base_url = self.video_server_url

            # Ensure no tasks are already running
            if self.rest_api is not None or self.websocket_api is not None:
                raise RuntimeError("Already started")

            self.robot.loop = asyncio.get_event_loop()

            while self.robot.running.is_set():
                # Restart both APIs if either one is disconnected
                if (
                    self.rest_api is None
                    or not self.robot.rest_api.is_connected
                    or self.websocket_api is None
                    or not self.robot.websocket_api.is_connected
                ):
                    # Cancel existing tasks
                    if self.rest_api:
                        await self.robot.rest_api.close()
                        self.rest_api.cancel()
                        self.rest_api = None

                    if self.websocket_api:
                        self.websocket_api.cancel()
                        self.websocket_api = None

                    # Restart REST API connection
                    self.rest_api = self.robot.loop.create_task(
                        self.robot.rest_api.start(
                            self.rest_api_url, self.api_key, self.set_jwt_token, self.get_jwt_token, self.use_uds
                        )
                    )

                    # Wait for REST API to connect
                    while not self.robot.rest_api.is_connected:
                        await asyncio.sleep(1)

                    # Restart WebSocket API connection
                    self.websocket_api = self.robot.loop.create_task(
                        self.robot.websocket_api.start(
                            self.websocket_api_url,
                            self.get_jwt_token,
                        )
                    )
                # Sleep before rechecking connection status
                await asyncio.sleep(1)

        async def connected(self) -> "BaseRobot.Connection":
            """Wait for the robot to connect to both REST and WebSocket APIs.

            Returns:
                BaseRobot.Connection: The connection instance, indicating successful connection.
            """
            logger.info("Waiting for robot to connect...")
            while (
                not (self.robot.rest_api.is_connected and self.robot.websocket_api.is_connected)
                and self.robot.running.is_set()
            ):
                await asyncio.sleep(0.1)
            logger.info("Robot connected.")
            return self

        def cancel(self) -> None:
            """Cancel the connection tasks and stop monitoring APIs."""
            if self.rest_api:
                self.rest_api.cancel()
            if self.websocket_api:
                self.websocket_api.cancel()

            self.robot.running.clear()
            if self.robot.loop:
                self.robot.loop.create_task(self.robot.rest_api.close())
                self.robot.loop.create_task(self.robot.websocket_api.close())
                self.robot.video_stream_manager.close_all_streams()
            try:
                self.finished.set_result(None)
            except asyncio.InvalidStateError:
                pass

        async def cancel_and_complete(self):
            """Stop both REST & WebSocket tasks, wait for them to finish, close sessions."""
            await self.robot.cancel_client_missions()

            if self.rest_api:
                self.rest_api.cancel()
            if self.websocket_api:
                self.websocket_api.cancel()
            await asyncio.sleep(0.1)
            self.robot.running.clear()

            await self.robot.rest_api.close()
            self.robot.video_stream_manager.close_all_streams()

            if self.robot.loop:
                websocket_closed = self.robot.loop.create_task(self.robot.websocket_api.close())
                try:
                    await websocket_closed
                except Exception as e:
                    logger.error(f"Error waiting for ws close: {e}")

            try:
                self.finished.set_result(None)
            except asyncio.InvalidStateError:
                pass

        async def completed(self) -> None:
            """Wait for the completion of all connection tasks."""
            await self.finished

    def connect(
        self,
        ip: Optional[str] = None,
        api_key: str = "",
    ) -> "BaseRobot.Connection":
        """Initiate the connection to the robot's APIs.

        Starts monitoring and fetching data from the REST and WebSocket APIs.

        Args:
            ip (Optional[str]): IP of the robot. If None or empty, defaults to UDS.
            api_key (str): API key of the robot.

        Returns:
            BaseRobot.Connection: The connection instance managing the APIs.
        """
        uds_path = "/tmp/rest_api.sock"  # nosec
        use_uds = not bool(ip)  # try to use UDS if IP is not specified

        if use_uds:
            rest_api_url = f"http+unix://{uds_path.replace('/', '%2F')}"
            websocket_api_url = f"ws://{get_local_ip()}:8001"
            video_server_url = "rtsp://localhost:8554"
        else:
            rest_api_url = f"http://{ip}:8000"
            websocket_api_url = f"ws://{ip}:8001"
            video_server_url = f"rtsp://{ip}:8554"

        self.connection = BaseRobot.Connection(
            self,
            rest_api_url=rest_api_url,
            websocket_api_url=websocket_api_url,
            video_server_url=video_server_url,
            api_key=api_key,
            use_uds=use_uds,
        )

        try:
            loop = asyncio.get_running_loop()
        except RuntimeError:

            def run() -> None:
                asyncio.run(self.connection.run_without_cancelled_error())

            self.thread = threading.Thread(target=run, name="connection_thread")
            self.thread.start()
        else:
            loop.create_task(self.connection.run())

        return self.connection

    @make_async
    def skill(self, skill: str, **kwargs: Any) -> Dict[str, Any]:
        """Trigger a skill on the robot.

        Args:
            skill (str): The name of the skill to trigger.
            **kwargs: Additional arguments for the skill.

        Returns:
            Dict[str, Any]: The response from the REST API containing the command and mission ID.
        """
        if kwargs:
            return self.send_dict("skill", {"name": skill, **kwargs})
        return self.send_dict("skill", {"name": skill})

    @make_async
    def wait_for_skill(self, id_mission: str) -> Dict[str, Any]:
        """Wait for a specific skill to complete.

        Args:
            id_mission (str): The mission ID to wait for.

        Returns:
            Dict[str, Any]: The response from the REST API indicating whether the mission was awaited.
        """
        return self.send_string("wait_for_skill", id_mission)

    @make_async
    def cancel_skill(self, id_mission: str) -> Dict[str, Any]:
        """Cancel a specific skill.

        Args:
            id_mission (str): The mission ID to cancel.

        Returns:
            Dict[str, Any]: The response from the REST API indicating whether the mission was cancelled.
        """
        return self.send_string("cancel_skill", id_mission)

    @make_async
    def wait_for_skill_started(self, id_mission: str) -> Dict[str, Any]:
        """Wait for a skill to start.

        Args:
            id_mission (str): The mission ID to wait for.

        Returns:
            Dict[str, Any]: The response from the REST API indicating whether the mission was started.
        """
        return self.send_string("wait_for_skill_started", id_mission)

    @make_async
    def cancel_and_wait_for_mission(self, id_mission: str) -> Dict[str, Any]:
        """Cancel a mission and wait for its completion.

        Args:
            id_mission (str): The mission ID to cancel.

        Returns:
            Dict[str, Any]: The response from the REST API indicating whether the mission was cancelled.
        """
        return self.send_string("cancel_and_wait_for_mission", id_mission)

    @make_async
    def cancel_client_missions(self) -> Dict[str, Any]:
        """Cancel a mission and wait for its completion.
        Returns:
            Dict[str, Any]: The response from the REST API indicating whether the mission was cancelled.
        """
        return self.send_command("cancel_client_missions")

    @make_async
    def get_skills(self) -> Dict[str, Any]:
        """Get the list of available skills.

        Returns:
            Dict[str, Any]: The response from the REST API.
        """
        return self.send_command("get_skills")

    @make_async
    def get_services_list(self) -> Dict[str, Any]:
        """Get the list of available services for logs.

        Returns:
            Dict[str, Any]: The list of available services.
        """
        return asyncio.run_coroutine_threadsafe(self.rest_api.get_services(), self.loop).result()

    @make_async
    def get_service_log(self, system: str, service: str) -> Dict[str, Any]:
        """Get logs for a specific service.

        Args:
            system (str): The system to get the service logs from (e.g., 'head', 'base').
            service (str): The service name.

        Returns:
            Dict[str, Any]: The logs from the specified service.
        """
        return asyncio.run_coroutine_threadsafe(
            self.rest_api.get_services(system=system, service=service), self.loop
        ).result()

    @make_async
    def send_command(self, command: str) -> Dict[str, Any]:
        """Send a simple command with no arguments to the REST API.

        Args:
            command (str): The command to send.

        Returns:
            Dict[str, Any]: The response from the REST API.
        """
        return asyncio.run_coroutine_threadsafe(
            self.rest_api.send_command("get", NoArgCommand(command=command)), self.loop
        ).result()

    @make_async
    def send_float(self, command: str, value: float) -> Dict[str, Any]:
        """Send a float command to the REST API.

        Args:
            command (str): The command to send.
            value (float): The float value to send.

        Returns:
            Dict[str, Any]: The response from the REST API.
        """
        return asyncio.run_coroutine_threadsafe(
            self.rest_api.send_command("float", FloatCommand(command=command, value=value)), self.loop
        ).result()

    @make_async
    def send_string(self, command: str, value: str) -> Dict[str, Any]:
        """Send a string command to the REST API.

        Args:
            command (str): The command to send.
            value (str): The string value to send.

        Returns:
            Dict[str, Any]: The response from the REST API.
        """
        return asyncio.run_coroutine_threadsafe(
            self.rest_api.send_command("str", StrCommand(command=command, value=value)), self.loop
        ).result()

    @make_async
    def send_boolean(self, command: str, value: bool) -> Dict[str, Any]:
        """Send a boolean command to the REST API.

        Args:
            command (str): The command to send.
            value (bool): The boolean value to send.

        Returns:
            Dict[str, Any]: The response from the REST API.
        """
        return asyncio.run_coroutine_threadsafe(
            self.rest_api.send_command("bool", BoolCommand(command=command, value=value)), self.loop
        ).result()

    @make_async
    def send_list(self, command: str, value: list[Any]) -> Dict[str, Any]:
        """Send a list command to the REST API.

        Args:
            command (str): The command to send.
            value (list[Any]): The list value to send.

        Returns:
            Dict[str, Any]: The response from the REST API.
        """
        return asyncio.run_coroutine_threadsafe(
            self.rest_api.send_command("list", ListCommand(command=command, value=value)), self.loop
        ).result()

    @make_async
    def send_dict(self, command: str, value: Dict[str, Any]) -> Dict[str, Any]:
        """Send a dictionary command to the REST API.

        Args:
            command (str): The command to send.
            value (Dict[str, Any]): The dictionary value to send.

        Returns:
            Dict[str, Any]: The response from the REST API.
        """
        return asyncio.run_coroutine_threadsafe(
            self.rest_api.send_command("dict", DictCommand(command=command, value=value)), self.loop
        ).result()

    @make_async
    def send_int(self, command: str, value: int) -> Dict[str, Any]:
        """Send an integer command to the REST API.

        Args:
            command (str): The command to send.
            value (int): The integer value to send.

        Returns:
            Dict[str, Any]: The response from the REST API.
        """
        return asyncio.run_coroutine_threadsafe(
            self.rest_api.send_command("int", IntCommand(command=command, value=value)), self.loop
        ).result()

    # skill management API methods
    @make_async
    def upload_skill_file(self, skill_path: str) -> dict:
        """Upload a skill file to the robot.

        Args:
            skill_path (str): The file path of the skill to upload.

        Returns:
            dict: The response from the REST API indicating the upload status.
        """
        return asyncio.run_coroutine_threadsafe(self.rest_api.upload_skill_file(skill_path), self.loop).result()

    @make_async
    def remove_skill_file(self, skill_name: str) -> dict:
        """Remove a skill file from the robot.

        Args:
            skill_name (str): The name of the skill to remove.

        Returns:
            dict: The response from the REST API indicating the removal status.
        """
        return asyncio.run_coroutine_threadsafe(self.rest_api.remove_skill_file(skill_name), self.loop).result()

    @make_async
    def list_skill_files(self) -> dict:
        """Retrieve a list of skills available on the robot.

        Returns:
            dict: A list of skills from the REST API.
        """
        return asyncio.run_coroutine_threadsafe(self.rest_api.list_skill_files(), self.loop).result()

    @make_async
    def enable_skill_file(self, skill_name: str, enable: bool) -> dict:
        """Enable or disable a skill on the robot.

        Args:
            skill_name (str): The name of the skill to enable or disable.
            enable (bool): Whether to enable (True) or disable (False) the skill.

        Returns:
            dict: The response from the REST API indicating the operation status.
        """
        return asyncio.run_coroutine_threadsafe(self.rest_api.enable_skill_file(skill_name, enable), self.loop).result()

    @make_async
    def subscribe(self, topic: str) -> None:
        """Subscribe to a WebSocket topic.

        Args:
            topic (str): The topic to subscribe to.
        """
        return asyncio.run_coroutine_threadsafe(self.websocket_api.subscribe(topic), self.loop).result()

    @make_async
    def unsubscribe(self, topic: str) -> None:
        """Unsubscribe from a WebSocket topic.

        Args:
            topic (str): The topic to unsubscribe from.
        """
        return asyncio.run_coroutine_threadsafe(self.websocket_api.unsubscribe(topic), self.loop).result()

    @make_async
    def publish(self, topic: str, data: str) -> None:
        """Publish data to a WebSocket topic.

        Args:
            topic (str): The topic to publish to.
            data (str): The data to publish (JSON format).
        """
        return asyncio.run_coroutine_threadsafe(self.websocket_api.publish(topic, data), self.loop).result()

    def register_callback(self, topic: str, callback: Callable[[Dict[str, Any]], None]) -> None:
        """Register a callback function for a WebSocket topic.

        Args:
            topic (str): The topic to register the callback for.
            callback (Callable[[Dict[str, Any]], None]): The callback function to call when a
            message is received for the topic.
        """
        self.websocket_api.register_callback(topic, callback)


class Robot(
    BaseRobot,
    Animate,
    Behavior,
    Freeze,
    Generic,
    Interact,
    Interaction,
    Manipulate,
    Navigate,
    Navigation,
    Planning,
    Runes,
    ShowOff,
    System,
    Transport,
):
    """Robot class that integrates all features and skills.

    This class extends BaseRobot and includes abilities and skills such as animation, behavior, interaction,
    manipulation, navigation, runes, and more, providing a comprehensive interface for interacting with
    the robot.

    Args:
        retry_interval (int): Time interval between retry attempts for API connections.
        api_version (str): API version to use for communication.
        loglevel (str): The level of logging detail.
    """

    def __init__(
        self,
        retry_interval: int = 5,
        api_version: str = "v1",
        loglevel: str = None,
    ) -> None:
        """Initialize the Robot with the specified settings.

        Args:
            retry_interval (int): Time interval between retry attempts for API connections.
            api_version (str): API version to use for communication.
            loglevel (str): The level of logging detail.
        """
        super().__init__(retry_interval, api_version, loglevel)


def connect(
    api_key: str = "",
    ip: Optional[str] = None,
) -> BaseRobot.Connection:
    """Initiate the connection to the robot's APIs.

    Starts monitoring and fetching data from the REST and WebSocket APIs.

    Args:
        api_key (str): API key of the robot
        ip (str): IP of the robot.

    Returns:
        BaseRobot.Connection: The connection instance managing the APIs.
        Do a `async with` of that object to have the connected robot object.
    """
    res = Robot()
    return res.connect(ip=ip, api_key=api_key)
