"""Models used for communication with the REST API."""

from pydantic import BaseModel


class Coordinates(BaseModel):
    """Defines a set of coordinates in a three-dimensional space along with an orientation.

    This model is used to represent spatial data with an optional rotational component,
    which is crucial for navigation and positioning tasks in a 3D environment.
    """

    x: float = 0.0
    """The X-coordinate in space, representing horizontal movement (forward/backward). Default is 0.0."""
    y: float = 0.0
    """The Y-coordinate in space, representing horizontal movement (left/right). Default is 0.0."""
    z: float = 0.0
    """The Z-coordinate in space, representing vertical movement (up/down). Default is 0.0."""
    theta: float = 0.0
    """The rotation around the Z-axis, in degrees. Default is 0.0."""

    def to_list(self) -> list:
        """Convert coordinates model to a [x, y, z] list."""
        return [self.x, self.y, self.z]


class StrCommand(BaseModel):
    """Represents a command that involves a string value.

    This model is used to process textual commands that modify settings or trigger actions
    within a system.
    """

    command: str
    """The command to be executed."""
    value: str
    """The string value associated with the command."""


class IntCommand(BaseModel):
    """Encapsulates a command that requires an integer value.

    This model is used for commands that adjust settings or configure parameters represented as integers.
    """

    command: str
    """The command to be executed."""
    value: int
    """The integer value necessary to carry out the command."""


class FloatCommand(BaseModel):
    """Defines a command that includes a floating-point number.

    Used for commands that involve precision settings or adjustments, such as configuring sensitivity levels.
    """

    command: str
    """The command to be executed."""
    value: float
    """The floating-point number that specifies the command's parameter."""


class BoolCommand(BaseModel):
    """Represents a command associated with a Boolean value.

    This model is crucial for enabling or disabling features through API commands, such as toggling settings.
    """

    command: str
    """The command to be executed."""
    value: bool
    """The Boolean state (True or False) that the command will apply."""


class DictCommand(BaseModel):
    """Models a command that involves dictionary data.

    Often used for commands requiring key-value pair configurations, particularly when adjusting complex settings.
    """

    command: str
    """The command to be executed."""
    value: dict
    """The dictionary containing configuration data or parameters for the command."""


class ListCommand(BaseModel):
    """Describes a command that involves a list of values.

    This model is used for commands that need to handle multiple elements, such as configuring a
    series of actions or settings.
    """

    command: str
    """The command name."""
    value: list
    """The list of values to be processed or configured by the command."""


class NoArgCommand(BaseModel):
    """Represents a command with no arguments.

    This model is used for commands that do not require any parameters.
    """

    command: str
    """The command name."""


class Rune(BaseModel):
    """Represents a rune."""

    id: str
    """The run virtual id."""


class Location(BaseModel):
    """Represents a location."""

    id: str
    """The location id."""


class EnchantedObject(Rune):
    """Represents a rune representing an object to grasp."""


class EnchantedLocation(Rune):
    """Represents a rune representing a location."""


class DepositZone(Rune):
    """Represents a deposit zone."""


class EnchantedUser(Rune):
    """Represents a rune representing a human."""
