"""Class to handle missions."""

import asyncio
import threading
from typing import Any, Optional
from datetime import timedelta


def start_loop(loop: asyncio.AbstractEventLoop) -> None:
    """Start the asyncio event loop in a separate thread.

    Args:
        loop (asyncio.AbstractEventLoop): The event loop to run.
    """
    asyncio.set_event_loop(loop)
    loop.run_forever()


class MissionError(Exception):
    """Exception raised when an await for a mission command fails."""

    pass


class MissionCancelledError(Exception):
    """Exception raised when a cancel mission command fails."""

    pass


MISSION_NOT_FOUND_MESSAGE = "Mission not found"


def serialize_timedelta(td: timedelta) -> dict:
    return {"days": td.days, "seconds": td.seconds, "microseconds": td.microseconds}


def serialize_kwargs(**kwargs: Any) -> dict:
    return {k: (serialize_timedelta(v) if isinstance(v, timedelta) else v) for k, v in kwargs.items()}


class Mission:
    """Class representing a mission for a robot, managing its lifecycle and state.

    This class interacts with the robot to initiate, monitor, and control missions.

    Attributes:
        robot (Any): The robot instance to interact with.
        skill (str): The skill to be performed by the robot.
        kwargs (dict): Additional arguments for the skill.
        mission_id (asyncio.Future): Future object representing the mission ID.
        result (asyncio.Future): Future object representing the mission result.
        start_result (asyncio.Future): Future object representing the start result of the mission.
    """

    def __init__(self, robot: Any, skill: str, **kwargs: Any) -> None:
        """Initialize the Mission class.

        Args:
            robot (Any): The robot instance to interact with.
            skill (str): The skill to be performed by the robot.
            kwargs (dict): Additional arguments for the skill.
        """
        self.robot = robot
        self.skill = skill
        self.kwargs = serialize_kwargs(**kwargs)
        self.mission_id = asyncio.Future()
        self.result = asyncio.Future()
        self.start_result = asyncio.Future()

        # Get the current event loop or create a new one if not available
        try:
            loop = asyncio.get_running_loop()
        except RuntimeError:
            loop = asyncio.new_event_loop()
            thread = threading.Thread(target=start_loop, args=(loop,), daemon=True)
            thread.start()
            asyncio.run_coroutine_threadsafe(self._async_init(), loop)
        else:
            loop.create_task(self._async_init())

    async def _async_init(self) -> None:
        """Initialize the mission asynchronously by calling the robot's skill method."""
        api_return_dict = await self.robot.skill(self.skill, **self.kwargs)
        res = api_return_dict["result"]
        if res["called"]:
            self.mission_id.set_result(res["msg"])
            # Store the result in this mission object
            try:
                ret = await self.robot.wait_for_skill(await self.mission_id)
                self.start_result.set_result(ret["result"]["start_result"])
                if ret["result"]["awaited"]:
                    self.result.set_result(ret)
                else:
                    self.result.set_exception(MissionError(ret["result"]["msg"]))
            except Exception as e:
                self.result.set_exception(e)
        else:
            self.mission_id.set_exception(MissionError(res["msg"]))
            self.result.set_exception(MissionError(res["msg"]))

    async def cancel(self, ignore_exceptions: bool = False) -> bool:
        """Cancel the current mission.

        Args:
            ignore_exceptions (bool): Catch the exception if the mission failed.

        Returns:
            bool: True if the cancel succeeded, False if not.
        """
        ret = await self.robot.cancel_skill(await self.mission_id)
        if not ret["result"]["cancelled"]:
            if not ignore_exceptions and ret["result"]["msg"] != MISSION_NOT_FOUND_MESSAGE:
                raise MissionCancelledError(ret["result"]["msg"])
            else:
                return False
        return True

    async def cancel_and_complete(self, ignore_exceptions: bool = False) -> bool:
        """Cancel the current mission and wait for its completion.

        Args:
            ignore_exceptions (bool): Catch the exception if the mission failed.

        Returns:
            bool: True if the cancel succeeded, False if not.
        """
        ret = await self.robot.cancel_and_wait_for_mission(await self.mission_id)
        if not ret["result"]["cancelled"]:
            if not ignore_exceptions and ret["result"]["msg"] != MISSION_NOT_FOUND_MESSAGE:
                raise MissionCancelledError(ret["result"]["msg"])
            else:
                return False
        return True

    async def completed(self, ignore_exceptions: bool = False) -> Optional[dict]:
        """Wait for the mission to complete.

        Args:
            ignore_exceptions (bool): Catch the exception if the mission failed to complete.
        """
        try:
            await self.result
            return self.result.result()
        except (asyncio.CancelledError, Exception):
            if ignore_exceptions:
                return None
            raise

    async def started(self, ignore_exceptions: bool = False) -> "Mission":
        """Wait until the mission has started.

        Args:
            ignore_exceptions (bool): Catch the exception if the mission failed to start.

        Returns:
            Mission: The mission instance if the mission has started successfully.

        Raises:
            MissionError: If the mission start failed or the mission was not found.
        """
        mission_id = await self.mission_id
        ret = await self.robot.wait_for_skill_started(mission_id)

        if not ret["result"]["started"]:
            # If the mission is not found it means it is already finished
            if not ignore_exceptions and ret["result"]["msg"] == MISSION_NOT_FOUND_MESSAGE:
                # Then we return the cached start result
                start_result = await self.start_result
                if not start_result["started"]:
                    raise MissionError(start_result["msg"])
                return self
            raise MissionError(ret["result"]["msg"])
        return self
