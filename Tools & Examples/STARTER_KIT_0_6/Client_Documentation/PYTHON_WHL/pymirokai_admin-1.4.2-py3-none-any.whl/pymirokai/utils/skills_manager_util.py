import argparse
import asyncio
import inspect
import json
import logging
import traceback
from pathlib import Path
from typing import Optional

from pymirokai.robot import Robot, connect
from pymirokai.core.skills_manager import SkillsManager
from pymirokai.utils.run_until_interruption import run_until_interruption

LOG = logging.getLogger("pymirokai")


async def run_skills_manager(robot: Robot, upload_dir: Path) -> None:
    """Main loop to control both skills and self-restart skills via robot JSON-RPC interface."""
    error = False
    while robot.running.is_set():
        try:
            while not (robot.rest_api.is_connected and robot.websocket_api.is_connected and robot.running.is_set()):
                await asyncio.sleep(1)

            skills_manager = SkillsManager(upload_dir=upload_dir, robot=robot)
            asyncio.create_task(skills_manager.monitor_loop())

            await robot.subscribe("RPC_command")
            await robot.subscribe("skills_command")
            await robot.subscribe("self_restart_skills_command")

            async def rpc_callback(msg: dict):
                command = msg.get("command")
                loop = asyncio.get_event_loop()
                if command == "run":
                    await loop.run_in_executor(None, lambda: asyncio.run(handle_run(msg, robot, skills_manager)))
                elif command == "cancel":
                    await handle_cancel(msg, robot, skills_manager)

            async def skills_callback(msg: Optional[dict] = None):
                skills_manager.get_skills_list()
                await send_skills_list(robot, skills_manager)

            async def self_restart_skills_callback(msg: Optional[dict] = None):
                skills_manager.get_skills_list()
                await send_self_restart_skills_list(robot, skills_manager)

            robot.register_callback("RPC_command", rpc_callback)
            robot.register_callback("skills_command", skills_callback)
            robot.register_callback("self_restart_skills_command", self_restart_skills_callback)

            while robot.rest_api.is_connected and robot.websocket_api.is_connected and robot.running.is_set():
                await asyncio.gather(
                    send_skills_list(robot, skills_manager),
                    send_self_restart_skills_list(robot, skills_manager),
                )
                if error:
                    await robot.publish(
                        topic="skill_manager_errors",
                        data=json.dumps(
                            {
                                "name": "skill_manager_errors",
                                "type": "str",
                                "data": "no_error",
                                "client_id": robot.rest_api.client_id,
                            }
                        ),
                    )
                    error = False
                await asyncio.sleep(1)

            if not robot.websocket_api.is_connected:
                LOG.warning("API disconnected. Restarting manager...")

        except Exception as e:
            error = True
            LOG.error(f"Error in manager: {e}")
            await robot.publish(
                topic="skill_manager_errors",
                data=json.dumps(
                    {
                        "name": "skill_manager_errors",
                        "type": "str",
                        "data": str(traceback.format_exc()),
                        "client_id": robot.rest_api.client_id,
                    }
                ),
            )
        await asyncio.sleep(1)


async def handle_run(msg: dict, robot: Robot, skills_manager: SkillsManager):
    rpc_request = msg["data"]
    method = rpc_request.get("method")
    params = rpc_request.get("params", {})
    request_id = rpc_request.get("id")

    try:
        result = await skills_manager.call_skill(method, **params)
        if inspect.isawaitable(result):
            result = await result
        response = {"jsonrpc": "2.0", "result": result, "id": request_id}
    except Exception as e:
        response = {
            "jsonrpc": "2.0",
            "error": {"code": -32603, "message": str(e)},
            "id": request_id,
            "client_id": robot.rest_api.client_id,
        }

    await robot.publish(
        topic="RPC_result",
        data=json.dumps(
            {
                "name": "RPC_result",
                "type": "dict",
                "data": json.dumps(response, default=str),
                "client_id": robot.rest_api.client_id,
            }
        ),
    )


async def handle_cancel(msg: dict, robot: Robot, skills_manager: SkillsManager):
    name = msg.get("function_name")
    request_id = msg.get("request_id")

    cancelled = False
    if name in skills_manager.list_running_skills():
        await skills_manager.cancel_skill(name)
        cancelled = True
    elif name in skills_manager.list_running_self_restart_skills():
        await skills_manager.cancel_skill(name)
        cancelled = True

    await robot.publish(
        topic="RPC_result",
        data=json.dumps(
            {
                "name": "RPC_result",
                "type": "dict",
                "client_id": robot.rest_api.client_id,
                "data": json.dumps(
                    {
                        "jsonrpc": "2.0",
                        "result": {"status": "CANCELLED" if cancelled else "NOT_RUNNING"},
                        "id": request_id,
                    }
                ),
            }
        ),
    )


async def send_skills_list(robot: Robot, skills_manager: SkillsManager):
    skills = {name: skill for name, skill in skills_manager.serialize_skills().items() if not skill.get("self_restart")}
    await robot.publish(
        topic="skills_list_result",
        data=json.dumps(
            {
                "name": "skills_list_result",
                "type": "dict",
                "data": skills,
                "client_id": robot.rest_api.client_id,
            }
        ),
    )


async def send_self_restart_skills_list(robot: Robot, skills_manager: SkillsManager):
    skills = {name: skill for name, skill in skills_manager.serialize_skills().items() if skill.get("self_restart")}
    await robot.publish(
        topic="self_restart_skills_list_result",
        data=json.dumps(
            {
                "name": "self_restart_skills_list_result",
                "type": "dict",
                "data": skills,
                "client_id": robot.rest_api.client_id,
            }
        ),
    )


async def run(ip: str, api_key: str, upload_dir: str) -> None:
    """Connect to robot and run skills manager."""
    async with connect(ip=ip, api_key=api_key) as robot:
        await run_skills_manager(robot, Path(upload_dir))


async def main() -> None:
    """Main entry point for CLI usage."""
    parser = argparse.ArgumentParser(formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("-i", "--ip", help="Set the IP of the robot you want to connect to.", type=str, default=None)
    parser.add_argument("-k", "--api-key", help="Set the API key of the robot.", type=str, default="")
    parser.add_argument(
        "-d", "--upload-dir", help="Path to the skill directory.", type=str, default=str(Path.home() / "skills")
    )

    args = parser.parse_args()

    await run(ip=args.ip, api_key=args.api_key, upload_dir=args.upload_dir)


def start_skills_manager():
    """CLI-compatible entry point."""
    run_until_interruption(main)
