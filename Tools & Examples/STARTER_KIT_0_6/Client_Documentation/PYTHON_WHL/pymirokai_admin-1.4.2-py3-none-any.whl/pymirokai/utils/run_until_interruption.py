"""Run an async function until interrupted."""

import asyncio
from typing import Callable, Awaitable
import signal


def run_until_interruption(callback: Callable[[], Awaitable[None]]) -> None:
    """Run an async callback that gracefully handles SIGINT and SIGTERM, ensuring all tasks are cancelled."""

    loop = asyncio.get_event_loop()

    def handle_exit():
        for task in asyncio.all_tasks(loop=loop):
            task.cancel()

    for sig in (signal.SIGINT, signal.SIGTERM):
        loop.add_signal_handler(sig, handle_exit)

    try:
        loop.run_until_complete(_async_cancelled_error_catcher(callback))
    finally:
        pending = asyncio.all_tasks(loop=loop)
        for task in pending:
            task.cancel()

        loop.run_until_complete(asyncio.gather(*pending, return_exceptions=True))
        loop.run_until_complete(loop.shutdown_asyncgens())
        loop.close()


async def _async_cancelled_error_catcher(callback: Callable[[], Awaitable[None]]) -> None:
    """Run the async callback and catch asyncio.CancelledError.

    Args:
        callback (Callable[[], Awaitable[None]]): The async function to run.
    """
    try:
        await callback()
    except asyncio.CancelledError:
        pass
