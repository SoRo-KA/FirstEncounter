from dataclasses import dataclass, field
from functools import wraps

from pymirokai.enums.enums import AccessLevel
from typing import Callable, Any


@dataclass(frozen=True)
class ParameterDescription:
    """ "Class used to describe in natural language the parameters for llm function calling.

    Args:
        name: name of the parameter to add.
        description (str): Description in natural language of the parameter.
    """

    name: str
    description: str
    questions: list = field(default_factory=list)


def skill(
    verbal_descriptions: dict[str, str] = {},
    parameters: list[ParameterDescription] = [],
    access_level: AccessLevel = AccessLevel.USER,
    self_restart: bool = False,
):
    """Decorator to wrap a named function into a skill and attach the skill info.

    The name of the function becomes the name of the skill.

    Args:
        verbal_descriptions (Optional[dict[Locale, str]]): Verbal description for voice triggering and
            LLM history filling.
        parameters (Optional[list[ParameterDescription]]): Parameters description to have the LLM automatically
            set this parameter.
        access_level (AccessLevel): How much rights are needed to start this skill from client API.
            SYSTEM means not accessible at all by client API. Default value is SYSTEM.

    """

    def decorator(func: Callable) -> Callable:
        # Attach metadata to the function
        func.self_restart = self_restart
        func.skill_info = {
            "verbal_descriptions": verbal_descriptions,
            "parameters": parameters,
            "access_level": access_level,
        }

        # Wrap the function to preserve its signature and functionality
        @wraps(func)
        def wrapper(*args: Any, **kwargs: Any) -> Any:
            return func(*args, **kwargs)

        return wrapper

    return decorator
