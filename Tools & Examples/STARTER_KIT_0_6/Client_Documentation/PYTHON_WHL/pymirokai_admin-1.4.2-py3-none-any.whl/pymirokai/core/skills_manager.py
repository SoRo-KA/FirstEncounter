import asyncio
import importlib
import inspect
import json
import logging
import traceback
from pathlib import Path
from typing import Any, Dict, List

from pymirokai.robot import Robot
from pymirokai.utils.serialize_data import serialize_data

LOG = logging.getLogger("pymirokai")


class SkillsManager:
    """Manages custom (foreground) skills that can be called once and produce results."""

    def __init__(self, upload_dir: Path, robot: Robot):
        """
        Initialize the SkillsManager.

        Args:
            upload_dir (Path): Directory containing skill files.
            robot (Robot): Robot instance to pass into skill functions if needed.
        """
        self.robot = robot
        self.upload_dir = upload_dir
        self.skills: Dict[str, Dict[str, Any]] = {}
        self.self_restart_skills: Dict[str, Dict[str, Any]] = {}
        self.running_skills: Dict[str, asyncio.Task] = {}
        self.running_self_restart_skills: Dict[str, asyncio.Task] = {}
        self.get_skills_list()

    def get_skills_list(self) -> Dict[str, Dict[str, Any]]:
        """
        Load skills and self-restart skills from all `.py` files in the upload directory.

        Returns:
            Dict[str, Dict[str, Any]]: Mapping of skill name to metadata.
        """
        self.skills = {}
        for file_path in self.upload_dir.glob("*.py"):
            try:
                skills, self_restart_skills = self.get_skill_info(file_path)
                self.skills.update(skills)
                self.self_restart_skills.update(self_restart_skills)
            except Exception as e:
                LOG.error(f"Error loading skill from {file_path}: {e}")
                self.robot.publish(
                    topic="skill_manager_errors",
                    data=json.dumps(
                        {
                            "name": "skill_manager_errors",
                            "type": "str",
                            "data": f"Error loading skill from {file_path}: {traceback.format_exc()}",
                            "client_id": self.robot.rest_api.client_id,
                        }
                    ),
                )

        return self.skills, self.self_restart_skills

    def get_skill_info(self, file_path: Path) -> tuple[Dict[str, Any], Dict[str, Any]]:
        """
        Extract decorated skills and self_restart_skills from a single Python file.

        Args:
            file_path (Path): File to inspect.

        Returns:
            Tuple[Dict[str, Any], Dict[str, Any]]: Found skills and self_restart_skills.
        """
        module_name = file_path.stem
        spec = importlib.util.spec_from_file_location(module_name, file_path)
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)

        skills = {}
        self_restart_skills = {}

        for name, obj in inspect.getmembers(module, inspect.isfunction):
            if hasattr(obj, "skill_info"):
                self_restart = getattr(obj, "self_restart", None)
                signature = inspect.signature(obj)
                details = {
                    "self_restart": self_restart,
                    "skill_info": getattr(obj, "skill_info", {}),
                    "parameters": [
                        {
                            "name": param.name,
                            "default": param.default if param.default != inspect.Parameter.empty else None,
                            "annotation": param.annotation if param.annotation != inspect.Parameter.empty else "",
                            "questions": [],
                        }
                        for param in signature.parameters.values()
                    ],
                    "function": obj,
                    "filename": file_path.name,
                    "enabled": not file_path.name.startswith("disabled."),
                    "client_id": self.robot.rest_api.client_id,
                }
                if self_restart:
                    self_restart_skills[name] = details
                else:
                    skills[name] = details

        return skills, self_restart_skills

    async def call_skill(self, function_name: str, *args, **kwargs) -> Dict[str, Any]:
        if function_name not in self.skills and function_name not in self.self_restart_skills:
            raise ValueError(f"Skill '{function_name}' not found.")

        skill_details = self.skills.get(function_name, self.self_restart_skills.get(function_name))
        function = skill_details["function"]
        parameters = skill_details["parameters"]

        expected_params = {param["name"]: param for param in parameters}
        for key in kwargs:
            if key not in expected_params:
                raise ValueError(f"Unexpected parameter '{key}' for skill '{function_name}'")

        for index, param in enumerate(parameters):
            if index >= len(args):
                break
            if param["annotation"] and not isinstance(args[index], param["annotation"]):
                raise TypeError(
                    f"Parameter '{param['name']}' expects type {param['annotation']}, got {type(args[index])}."
                )

        async def execute_skill():
            try:
                # Inject robot if expected but not provided
                if "robot" in expected_params and "robot" not in kwargs:
                    kwargs["robot"] = self.robot
                LOG.info(f"Executing skill '{function_name}' with args={args}, kwargs={kwargs}.")

                result = (
                    await function(*args, **kwargs)
                    if inspect.iscoroutinefunction(function)
                    else function(*args, **kwargs)
                )

                if inspect.isawaitable(result):
                    result = await result

                return {"value": result, "status": "COMPLETED"}
            except asyncio.CancelledError:
                LOG.warning(f"Skill '{function_name}' was cancelled.")
                return {"value": None, "status": "CANCELLED"}
            except Exception as e:
                LOG.error(f"Error executing skill '{function_name}': {e}")
                return {"value": None, "status": "ERROR", "exception": str(e)}

        task = asyncio.create_task(execute_skill())
        if skill_details["self_restart"]:
            self.running_self_restart_skills[function_name] = task
            result = await task
            self.running_self_restart_skills.pop(function_name, None)
        else:
            self.running_skills[function_name] = task
            result = await task
            self.running_skills.pop(function_name, None)

        return result

    async def cancel_skill(self, function_name: str) -> None:
        """
        Cancel a currently running skill.

        Args:
            function_name (str): Name of the skill to cancel.
        """
        task = self.running_skills.get(function_name)
        if not task:
            LOG.warning(f"Skill '{function_name}' is not running.")
            return

        LOG.info(f"Cancelling skill '{function_name}'.")
        task.cancel()
        try:
            await task
        except asyncio.CancelledError:
            LOG.info(f"Skill '{function_name}' cancelled successfully.")
        finally:
            self.running_skills.pop(function_name, None)

    async def cancel_self_restart_skill(self, function_name: str) -> None:
        """
        Cancel a currently running skill.

        Args:
            function_name (str): Name of the skill to cancel.
        """
        task = self.running_self_restart_skills.get(function_name)
        if not task:
            LOG.warning(f"Self-restart skill '{function_name}' is not running.")
            return

        LOG.info(f"Cancelling self-restart skill '{function_name}'.")
        task.cancel()
        try:
            await task
        except asyncio.CancelledError:
            LOG.info(f"Skill '{function_name}' cancelled successfully.")
        finally:
            self.running_self_restart_skills.pop(function_name, None)

    async def monitor_loop(self, interval: float = 1.0) -> None:
        """
        Continuously monitor and reload skills on disk.

        Args:
            interval (float): Time between checks.
        """
        while True:
            try:
                await self.update_skills()
            except Exception as e:
                LOG.error(f"Error in skill monitoring loop: {e}")
            await asyncio.sleep(interval)

    async def update_skills(self) -> None:
        """
        Refresh skill list and cancel any removed or disabled ones.
        """
        self.get_skills_list()
        to_cancel_skills = {
            skill
            for skill in self.running_skills
            if skill not in self.skills
            or not self.skills[skill]["enabled"]
            and skill["client_id"] == self.robot.rest_api.client_id
        }
        to_cancel_self_restart_skills = {
            skill
            for skill in self.running_self_restart_skills
            if skill not in self.self_restart_skills
            or not self.self_restart_skills[skill]["enabled"]
            and skill["client_id"] == self.robot.rest_api.client_id
        }

        await asyncio.gather(
            *(self.cancel_skill(skill) for skill in to_cancel_skills),
            *(self.cancel_self_restart_skill(skill) for skill in to_cancel_self_restart_skills),
        )

    def list_running_skills(self) -> List[str]:
        """
        Return a list of running skills.

        Returns:
            List[str]: Skill names.
        """
        return list(self.running_skills.keys())

    def list_running_self_restart_skills(self) -> List[str]:
        """
        Return a list of running self-restart skills.

        Returns:
            List[str]: Self-restart skill names.
        """
        return list(self.running_self_restart_skills.keys())

    def serialize_skills(self) -> Dict[str, Any]:
        """
        Serialize skill metadata for external use.

        Returns:
            Dict[str, Any]: Skill details without actual function references.
        """
        return {
            skill_name: {
                "skill_info": serialize_data(details.get("skill_info", {})),
                "parameters": serialize_data(details.get("parameters", [])),
                "filename": serialize_data(details.get("filename", "")),
                "self_restart": serialize_data(details.get("self_restart", "")),
                "enabled": serialize_data(details.get("enabled", False)),
                "client_id": serialize_data(details.get("client_id", "")),
            }
            for skill_name, details in [*self.skills.items(), *self.self_restart_skills.items()]
        }
