#!/usr/bin/env python3
"""This module contains the navigation-related features of the robot."""

from typing import Dict, Any
from pymirokai.utils.async_wrapper import make_async


class Navigation:
    """Class to handle navigation-related features of the robot."""

    @make_async
    def set_robot_max_velocity(self, percentage: float) -> Dict[str, Any]:
        """Set the maximum velocity at which the robot can operate.

        Args:
            velocity (float): The maximum velocity in percent.

        Returns:
            Dict[str, Any]: The response from the REST API.
        """
        velocity = max(0, min(100, percentage))
        return self.send_float("set_robot_max_velocity", velocity)
