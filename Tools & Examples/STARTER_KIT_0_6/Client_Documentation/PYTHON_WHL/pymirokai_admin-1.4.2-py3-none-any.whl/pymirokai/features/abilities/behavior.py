#!/usr/bin/env python3
"""This module contains the behavior-related features of the robot."""

from typing import Dict, Any
from pymirokai.models.data_models import Location
from pymirokai.utils.async_wrapper import make_async


class Behavior:
    """Class to handle behavior-related features of the robot."""

    @make_async
    def set_obstacle_avoidance(self, enabled: bool) -> Dict[str, Any]:
        """Activate or deactivate the obstacle avoidance feature.

        Args:
            enabled (bool): True to enable, False to disable.

        Returns:
            Dict[str, Any]: The response from the REST API.
        """
        return self.send_boolean("set_obstacle_avoidance", enabled)

    @make_async
    def exit_arms_collision(self) -> Dict[str, Any]:
        """Exit current arms collision.

        Returns:
            Dict[str, Any]: The response from the REST API.
        """
        return self.send_command("exit_arms_collision")

    async def list_all_locations(self) -> list[Location]:
        """List all the currently known locations by the robot.

        Returns:
            Dict[str, Any]: The locations.
        """
        loc_ids = await self.send_command("list_all_location_ids")
        loc_ids_list = loc_ids["result"]
        if isinstance(loc_ids_list, list):
            return [Location(id=loc_id) for loc_id in loc_ids_list]
        else:
            raise ValueError(f"The list of locations is not a list: {loc_ids_list}")
