#!/usr/bin/env python3
"""This module contains the interact-related features of the robot."""
from typing import Optional
from pymirokai.mission import Mission
from pymirokai.enums import Arm
from pymirokai.utils.converter import arm_to_arm_entity_identifier


class InteractUser:
    """Class to handle interact-related features of the robot."""

    def acknowledge_engagement(self) -> Mission:
        """Acknowledge engagement with the robot.

        Returns:
            Mission: The mission representing the task.
        """
        return Mission(self, "acknowledge_engagement")

    def describe_what_you_see(self, language: str = "en") -> Mission:
        """Describe the robot's surroundings by taking a picture.

        WARNING: This function uploads the picture to a cloud service for processing.

        Args:
            language (str): The language in which to describe the surroundings.
                Defaults to "en".

        Returns:
            Mission: The mission representing the task.
        """
        return Mission(self, "describe_what_you_see", language=language)

    def express_joy(self) -> Mission:
        """Express joy.

        Returns:
            Mission: The mission representing the task.
        """
        return Mission(self, "express_joy")

    def kiss(self) -> Mission:
        """Perform a kiss action.

        Returns:
            Mission: The mission representing the task.
        """
        return Mission(self, "kiss")

    def soft_coo(self) -> Mission:
        """Produce a cooing sound.

        Returns:
            Mission: The mission representing the task.
        """
        return Mission(self, "soft_coo")

    def say(self, something: str, autonomous_reaction: bool = True) -> Mission:
        """Say something with emotion and autonomous reaction.

        Args:
            something (str): The text to say.
            autonomous_reaction (bool): Whether to react autonomously.

        Returns:
            Mission: The mission representing the task.
        """
        return Mission(self, "say", something=something, autonomous_reaction=autonomous_reaction)

    def start_conversation(self) -> Mission:
        """Activate llm and enable the conversation.

        Returns:
            Mission: The mission representing the task.
        """
        return Mission(self, "start_conversation")

    def stop_conversation(self) -> Mission:
        """Deactivate llm and disable the conversation.

        Returns:
            Mission: The mission representing the task.
        """
        return Mission(self, "stop_conversation")

    def start_or_stop_conversation(self) -> Mission:
        """Deactivate llm and disable the conversation or Activate llm and enable the conversation.

        Returns:
            Mission: The mission representing the task.
        """
        return Mission(self, "start_or_stop_conversation")

    def wave(self, arm: Optional[Arm] = None) -> Mission:
        """Wave with a specified arm or both arms.

        Args:
            arm (Optional[Arm]): The arm to use for waving. If None, the robot waves with both arms.

        Returns:
            Mission: The mission representing the task.
        """
        if not arm:
            return Mission(self, "wave")
        return Mission(self, "wave", arm=arm_to_arm_entity_identifier(arm))

    def start_or_stop_actions_by_voice(self) -> Mission:
        """Deactivate or activate actions by voice.

        Returns:
            Mission: The mission representing the task.
        """
        return Mission(self, "start_or_stop_actions_by_voice")

    def checkup_ears(self) -> Mission:
        """Check mirokai ears.

        Returns:
            Mission: The mission representing the task.
        """
        return Mission(self, "checkup_ears")

    def japanese_greeting(self) -> Mission:
        """Do a japanese greeting.

        Returns:
            Mission: The mission representing the task.
        """
        return Mission(self, "japanese_greeting")

    def happy_kiss(self) -> Mission:
        """Send a happy kiss.

        Returns:
            Mission: The mission representing the task.
        """
        return Mission(self, "happy_kiss")

    def shy_kiss(self) -> Mission:
        """Send a shy kiss.

        Returns:
            Mission: The mission representing the task.
        """
        return Mission(self, "shy_kiss")

    def check_internet_connectivity(self) -> Mission:
        """Check current internet connectivity.

        Returns:
            Mission: The mission representing the task.
        """
        return Mission(self, "check_internet_connectivity")
