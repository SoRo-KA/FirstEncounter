#!/usr/bin/env python3
"""This module contains the manipulate-related features of the robot."""
from typing import Any
from pymirokai.mission import Mission


class PlanningAdmin:
    """Class to handle planning features of the robot."""

    def set_autonomous_goals(self, goals: list[dict[str, Any]]) -> Mission:
        return Mission(self, "set_autonomous_goals", goals=goals)

    def get_autonomous_goals(self) -> Mission:
        return Mission(self, "get_autonomous_goals")

    def set_user_goal_definitions(self, definitions: dict[str, list[dict[str, dict]]]) -> Mission:
        return Mission(self, "set_user_goal_definitions", definitions=definitions)

    def get_user_goal_definitions(self) -> Mission:
        return Mission(self, "get_user_goal_definitions")

    def get_system_goal_definitions(self) -> Mission:
        return Mission(self, "get_system_goal_definitions")

    def apply_pddl_effect(self, pddl_effect: str) -> Mission:
        return Mission(self, "apply_pddl_effect", pddl_effect=pddl_effect)
