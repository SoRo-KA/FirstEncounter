#!/usr/bin/env python3
"""This module contains the navigate-related features of the robot."""


class NavigateAdmin:
    """Class to handle navigate-related features of the robot."""
