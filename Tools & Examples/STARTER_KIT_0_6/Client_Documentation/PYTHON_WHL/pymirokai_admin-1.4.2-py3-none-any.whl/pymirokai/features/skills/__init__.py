# ruff: noqa

SKILL_LEVEL = "USER"

from pymirokai.features.skills.user.animate import AnimateUser
from pymirokai.features.skills.user.freeze import FreezeUser
from pymirokai.features.skills.user.interact import InteractUser
from pymirokai.features.skills.user.manipulate import ManipulateUser
from pymirokai.features.skills.user.navigate import NavigateUser
from pymirokai.features.skills.user.planning import PlanningUser
from pymirokai.features.skills.user.show_off import ShowOffUser
from pymirokai.features.skills.user.system import SystemUser
from pymirokai.features.skills.user.transport import TransportUser

try:
    from pymirokai.features.skills.admin.animate import AnimateAdmin
    from pymirokai.features.skills.admin.freeze import FreezeAdmin
    from pymirokai.features.skills.admin.interact import InteractAdmin
    from pymirokai.features.skills.admin.manipulate import ManipulateAdmin
    from pymirokai.features.skills.admin.navigate import NavigateAdmin
    from pymirokai.features.skills.admin.planning import PlanningAdmin
    from pymirokai.features.skills.admin.show_off import ShowOffAdmin
    from pymirokai.features.skills.admin.system import SystemAdmin
    from pymirokai.features.skills.admin.transport import TransportAdmin

    SKILL_LEVEL = "ADMIN"

    from pymirokai.features.skills.enchanter.animate import AnimateEnchanter
    from pymirokai.features.skills.enchanter.freeze import FreezeEnchanter
    from pymirokai.features.skills.enchanter.interact import InteractEnchanter
    from pymirokai.features.skills.enchanter.manipulate import ManipulateEnchanter
    from pymirokai.features.skills.enchanter.navigate import NavigateEnchanter
    from pymirokai.features.skills.enchanter.planning import PlanningEnchanter
    from pymirokai.features.skills.enchanter.show_off import ShowOffEnchanter
    from pymirokai.features.skills.enchanter.system import SystemEnchanter
    from pymirokai.features.skills.enchanter.transport import TransportEnchanter

    SKILL_LEVEL = "ENCHANTER"
except ImportError:
    pass

if SKILL_LEVEL == "USER":

    class Animate(AnimateUser):
        pass

    class Freeze(FreezeUser):
        pass

    class Interact(InteractUser):
        pass

    class Manipulate(ManipulateUser):
        pass

    class Navigate(NavigateUser):
        pass

    class Planning(PlanningUser):
        pass

    class ShowOff(ShowOffUser):
        pass

    class Transport(TransportUser):
        pass

    class System(SystemUser):
        pass

elif SKILL_LEVEL == "ADMIN":

    class Animate(AnimateUser, AnimateAdmin):
        pass

    class Freeze(FreezeUser, FreezeAdmin):
        pass

    class Interact(InteractUser, InteractAdmin):
        pass

    class Manipulate(ManipulateUser, ManipulateAdmin):
        pass

    class Navigate(NavigateUser, NavigateAdmin):
        pass

    class Planning(PlanningUser, PlanningAdmin):
        pass

    class ShowOff(ShowOffUser, ShowOffAdmin):
        pass

    class Transport(TransportUser, TransportAdmin):
        pass

    class System(SystemUser, SystemAdmin):
        pass

elif SKILL_LEVEL == "ENCHANTER":

    class Animate(AnimateUser, AnimateAdmin, AnimateEnchanter):
        pass

    class Freeze(FreezeUser, FreezeAdmin, FreezeEnchanter):
        pass

    class Interact(InteractUser, InteractAdmin, InteractEnchanter):
        pass

    class Manipulate(ManipulateUser, ManipulateAdmin, ManipulateEnchanter):
        pass

    class Navigate(NavigateUser, NavigateAdmin, NavigateEnchanter):
        pass

    class Planning(PlanningUser, PlanningAdmin, PlanningEnchanter):
        pass

    class ShowOff(ShowOffUser, ShowOffAdmin, ShowOffEnchanter):
        pass

    class Transport(TransportUser, TransportAdmin, TransportEnchanter):
        pass

    class System(SystemUser, SystemAdmin, SystemEnchanter):
        pass
