#!/usr/bin/env python3
"""This module contains the animate-related features of the robot."""


class AnimateAdmin:
    """Class to handle animate-related features of the robot."""
