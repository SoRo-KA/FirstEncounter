#!/usr/bin/env python3
"""This module contains the freeze-related features of the robot."""
from pymirokai.mission import Mission


class FreezeAdmin:
    """Class to handle freeze-related features of the robot."""

    def emergency_freeze(self) -> Mission:
        """Freeze all of the robot's movement.

        Returns:
            Mission: The mission representing the task.
        """
        return Mission(self, "emergency_freeze")

    def emergency_unfreeze(self) -> Mission:
        """Resume the robot's movement after freezing.

        Returns:
            Mission: The mission representing the task.
        """
        return Mission(self, "emergency_unfreeze")
