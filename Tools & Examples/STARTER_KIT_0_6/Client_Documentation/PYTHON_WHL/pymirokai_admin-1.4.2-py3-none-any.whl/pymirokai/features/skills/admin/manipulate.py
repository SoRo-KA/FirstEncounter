#!/usr/bin/env python3
"""This module contains the manipulate-related features of the robot."""


class ManipulateAdmin:
    """Class to handle manipulate-related features of the robot."""
