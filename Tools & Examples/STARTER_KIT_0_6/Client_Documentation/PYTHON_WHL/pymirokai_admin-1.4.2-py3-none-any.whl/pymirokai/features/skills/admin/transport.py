#!/usr/bin/env python3
"""This module contains the transport-related features of the robot."""


class TransportAdmin:
    """Class to handle transport-related features of the robot."""
