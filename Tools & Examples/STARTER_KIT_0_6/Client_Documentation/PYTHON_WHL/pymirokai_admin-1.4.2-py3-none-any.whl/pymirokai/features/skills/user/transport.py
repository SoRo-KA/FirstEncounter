#!/usr/bin/env python3
"""This module contains the transport-related features of the robot."""
from pymirokai.mission import Mission
from pymirokai.models.data_models import DepositZone, EnchantedObject


class TransportUser:
    """Class to handle transport-related features of the robot."""

    def grasp_handle_on_deposit(self, rune: EnchantedObject) -> Mission:
        """Grasp a handle at a deposit zone.

        Args:
            rune (EnchantedObject): The enchanted object representing the handle.

        Returns:
            Mission: The mission representing the task.
        """
        return Mission(self, "grasp_handle_on_deposit", rune=rune.id)

    def put_down_handle_on_deposit(self, handle: EnchantedObject, destination: DepositZone) -> Mission:
        """Place a handle at a specified deposit zone.

        Args:
            handle (EnchantedObject): The handle to place.
            destination (DepositZone): The destination deposit zone.

        Returns:
            Mission: The mission representing the task.
        """
        return Mission(self, "put_down_handle_on_deposit", handle=handle.id, destination=destination.id)
