#!/usr/bin/env python3
"""This module contains the animate-related features of the robot."""
from pymirokai.enums import Arm, Ear, Hand
from pymirokai.mission import Mission
from pymirokai.utils.converter import arm_to_arm_entity_identifier, ear_to_ear_entity_identifier


class AnimateUser:
    """Class to handle animate-related features of the robot."""

    def animate_arms(self, anim_name: str) -> Mission:
        """Animate both of the robot's arms.

        Args:
            anim_name (str): The name of the animation to play.

        Returns:
            Mission: The mission representing the animation task.
        """
        return Mission(self, "animate_arms", anim_name=anim_name)

    def animate_arm(self, anim_name: str, arm: Arm) -> Mission:
        """Animate the robot's arm.

        Args:
            anim_name (str): The name of the animation to play.
            arm (Arm): The arm to animate.

        Returns:
            Mission: The mission representing the animation task.
        """
        return Mission(self, "animate_arm", anim_name=anim_name, arm=arm_to_arm_entity_identifier(arm))

    def arms_down(self) -> Mission:
        """Move the robot's arms down.

        Returns:
            Mission: The mission representing the task.
        """
        return Mission(self, "arms_down")

    def move_ears_to_target(self, target_range: float) -> Mission:
        """Move both ears to a target range.

        Args:
            target_range (float): The target range to move the ears to.
                Valid values are between 0.0 (minimum) and 1.0 (maximum).

        Returns:
            Mission: The mission representing the task.
        """
        return Mission(self, "move_ears_to_target", target_range=target_range)

    def move_ear_to_target(self, ear: Ear, target_range: float) -> Mission:
        """Move a ear to a target range.

        Args:
            ear (Ear): The ear to move.
            target_range (float): The target range to move the ear to (between 0.0 and 1.0).

        Returns:
            Mission: The mission representing the task.

        Raises:
            RuntimeError: If the ear is not valid.
        """
        ear_entity = ear_to_ear_entity_identifier(ear)
        if ear_entity is None:
            raise RuntimeError("No ear to move")
        return Mission(self, "move_ear_to_target", ear=ear_entity, target_range=target_range)

    def play_face_reaction(
        self, emote_reaction: str, pause_expression: bool = True, speed_factor: float = 0.0
    ) -> Mission:
        """Play a face reaction.

        Args:
            emote_reaction (str): The emotion to react with.
            pause_expression (bool): Whether to pause the expression.
            speed_factor (float): The speed factor of the reaction.

        Returns:
            Mission: The mission representing the task.
        """
        return Mission(
            self,
            "play_face_reaction",
            emote_reaction=emote_reaction.value,
            pause_expression=pause_expression,
            speed_factor=speed_factor,
        )

    def play_face_reaction_range(self, emote_emotion: str, intensity: float = 0.8) -> Mission:
        """Play a face reaction within a specified intensity range.

        Args:
            emote_emotion (str): The emotion to react with.
            intensity (float): The intensity level of the reaction, between 0.0 and 1.0.
                Defaults to 0.8.

        Returns:
            Mission: The mission representing the task.
        """
        return Mission(self, "play_face_reaction_range", emote_emotion=emote_emotion, intensity=intensity)

    def play_animation_sound(self, animation_name: str, volume: float = 0.8) -> Mission:
        """Play sound paired with a face animation.

        Args:
            animation_name (str): The name of the animation containing the sound.
            volume (float): The volume of the sound, between 0.0 and 1.0.
                Defaults to 0.8.

        Returns:
            Mission: The mission representing the task.
        """
        return Mission(self, "play_animation_sound", animation_name=animation_name, volume=volume)

    def wriggle_ears(self, min_range: float = 0.5, max_range: float = 1.0, rounds: int = 3) -> Mission:
        """Wriggle the ears.

        Args:
            min_range (float): The minimum range of the wriggle (between 0.0 and 1.0).
            max_range (float): The maximum range of the wriggle (between 0.0 and 1.0).
            rounds (int): The number of rounds to wriggle.

        Returns:
            Mission: The mission representing the task.
        """
        return Mission(self, "wriggle_ears", min_range=min_range, max_range=max_range, rounds=rounds)

    def wriggle_ear(self, ear: Ear, min_range: float = 0.5, max_range: float = 1.0, rounds: int = 3) -> Mission:
        """Wriggle one ear.

        Args:
            ear (Ear): The ear to move.
            min_range (float): The minimum range of the wriggle (between 0.0 and 1.0).
            max_range (float): The maximum range of the wriggle (between 0.0 and 1.0).
            rounds (int): The number of rounds to wriggle.

        Returns:
            Mission: The mission representing the task.

        Raises:
            RuntimeError: If the ear is not valid.
        """
        ear_entity = ear_to_ear_entity_identifier(ear)
        if ear_entity is None:
            raise RuntimeError("No ear to move")
        return Mission(self, "wriggle_ear", ears=ear_entity, min_range=min_range, max_range=max_range, rounds=rounds)

    def hold_hand(self, hand: Hand) -> Mission:
        """Play animation to hold hand with specified arm.

        Returns:
            Mission: The mission representing the task.
        """
        return Mission(self, "hold_hand", hand=hand)

    def reset_ears(self) -> Mission:
        """Reset ears to their nominal position.

        Returns:
            Mission: The mission representing the task.
        """
        return Mission(self, "reset_ears")

    def wind_ears(self, frequency: float, min_range: float = 0.0, max_range: float = 1.0) -> Mission:
        """Wind robot's ears.

        Args:
            frequency (float): Frequency in Hz to wind ears
            min_range (float): Minimum range (between 0 and 1)
            max_range (float): Maximum range (between 0 and 1)
        Returns:
            Mission: The mission representing the task.
        """
        return Mission(self, "wind_ears", frequency=frequency, min_range=min_range, max_range=max_range)

    def lets_dance(self) -> Mission:
        """Put robot's arm in dance position.

        Returns:
            Mission: The mission representing the task.
        """
        return Mission(self, "lets_dance")

    def sniff_around(self) -> Mission:
        """Make the robot sniff around.

        Returns:
            Mission: The mission representing the task.
        """
        return Mission(self, "sniff_around")

    def body_scan(self) -> Mission:
        """Make the robot fake a body scan.

        Returns:
            Mission: The mission representing the task.
        """
        return Mission(self, "body_scan")

    def track_neck_and_wait_infinitely(self, focus_on: str = "everything") -> Mission:
        """Set the neck mode to 'track' and focus on something.

        Args:
            focus_on (str): set the focus on something (everything, handles, humans, deposit_zone, or firefly).
            Default to 'everything'
        """
        return Mission(self, "track_neck_and_wait_infinitely", focus_on=focus_on)

    def animate_neck_and_wait_infinitely(self) -> Mission:
        """Set the neck mode to 'animate'."""
        return Mission(self, "animate_neck_and_wait_infinitely")

    def freeze_neck_and_wait_infinitely(self) -> Mission:
        """Set the neck mode to 'freeze'."""
        return Mission(self, "freeze_neck_and_wait_infinitely")

    def scan_neck_and_wait_infinitely(self) -> Mission:
        """Set the neck mode to 'scan'."""
        return Mission(self, "scan_neck_and_wait_infinitely")

    def take_neck_resource_punctually(self) -> Mission:
        """Set the neck mode to 'auto'."""
        return Mission(self, "take_neck_resource_punctually")
